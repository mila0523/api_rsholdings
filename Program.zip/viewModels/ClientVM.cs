﻿namespace api_rsholdings.viewModels
{
    public class ClientVM
    {

    }
}
